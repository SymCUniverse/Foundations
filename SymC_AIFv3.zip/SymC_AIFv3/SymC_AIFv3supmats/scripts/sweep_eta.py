
import os, csv, math
import numpy as np
import matplotlib.pyplot as plt

from sigma_overdamped import (
    sigma_all, terminal_info, z_underdamped, z_crit, z_overdamped
)

# ---------------- Params ----------------
THETA = 6.0  # base dimensionless horizon Θ
ZETA_MIN, ZETA_MAX, N_ZETAS = 0.05, 3.0, 400

# To avoid accidental alignment with an underdamped antinode at tiny ζ,
# we average I over a small window around Θ.
WINDOW = math.pi  # span to sample around Θ
N_AVG = 41        # number of samples for averaging

taus = np.linspace(THETA - 0.5*WINDOW, THETA + 0.5*WINDOW, N_AVG)

def info_phase_averaged(zeta):
    zs = []
    for t in taus:
        if zeta < 1.0:
            z = z_underdamped(zeta, t)
        elif zeta == 1.0:
            z = z_crit(t)
        else:
            z = z_overdamped(zeta, t)
        zs.append(1.0 - z*z)
    return float(np.mean(zs))

# ---------------- Sweep -----------------
zetas = np.linspace(ZETA_MIN, ZETA_MAX, N_ZETAS)
I_vals = np.empty_like(zetas)
S_vals = np.empty_like(zetas)
eta_vals = np.empty_like(zetas)

for i, z in enumerate(zetas):
    zf = float(z)
    I = info_phase_averaged(zf)
    S = sigma_all(zf, THETA)
    I_vals[i] = I
    S_vals[i] = S
    eta_vals[i] = I / S if S > 0 else np.nan

# ---------------- Argmax ----------------
imax = int(np.nanargmax(eta_vals))
z_star = float(zetas[imax])
eta_star = float(eta_vals[imax])

print(f"[Phase-averaged] Argmax η at ζ* ≈ {z_star:.4f} (Θ={THETA}), η* ≈ {eta_star:.6f}")

# ---------------- Outputs ----------------
os.makedirs("figs", exist_ok=True)
os.makedirs("data", exist_ok=True)

# Save CSV
with open(os.path.join("data", "eta_sweep.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["zeta", "I_phase_avg", "Sigma", "eta"])
    for z, I, S, e in zip(zetas, I_vals, S_vals, eta_vals):
        w.writerow([f"{z:.8f}", f"{I:.12e}", f"{S:.12e}", f"{e:.12e}"])

# Plot η(ζ)
plt.figure()
plt.plot(zetas, eta_vals)
plt.axvline(1.0, linestyle="--")
plt.title("Efficiency η(ζ) (phase-averaged I)")
plt.xlabel("ζ")
plt.ylabel("η(ζ)")
plt.tight_layout()
plt.savefig(os.path.join("figs", "eta_curve.png"), dpi=200)

# Plot I and Σ
plt.figure()
plt.plot(zetas, I_vals, label="I(ζ) phase-avg")
plt.plot(zetas, S_vals, label="Σ(ζ)")
plt.axvline(1.0, linestyle="--")
plt.title("I(ζ) (phase-avg) and Σ(ζ) vs ζ")
plt.xlabel("ζ")
plt.ylabel("Value")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join("figs", "I_Sigma_curves.png"), dpi=200)
