#!/usr/bin/env python3
"""
figure3_from_csv.py

Rebuild Figure 3 directly from a canonical CSV so the plotted points are provably tied to the data.

Input CSV schema (required columns):
  System,Mass_eV,Width_eV,Chi,Category,Empirical,Notes

- x-axis: log10(omega) where omega := Mass_eV (natural units)
- y-axis: log10(Gamma) where Gamma := Width_eV
- chi lines: Gamma = 2*omega  (chi=1 boundary), plus optional chi=0.1, 0.01, 10 guides
- Empirical points are plotted as solid markers; non-empirical as hollow markers by default.

Usage:
  python figure3_from_csv.py --csv stability_table.csv --out Fig3_Rebuilt.png

Optional:
  --xmin --xmax --ymin --ymax to control plot window.
"""

from __future__ import annotations
import argparse
import math
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

REQUIRED = ["System","Mass_eV","Width_eV","Chi","Category","Empirical","Notes"]

# Category -> (marker, size)
CAT_STYLE = {
    "Vacuum": ("D", 70),
    "Lepton": ("o", 55),
    "Quark": ("s", 55),
    "Boson": ("^", 60),
    "Meson": ("v", 55),
    "Baryon": ("P", 65),
    "Nuclear": ("X", 60),
    "Astro": ("*", 90),
    "Cosmology": ("D", 70),
}

def load_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    # Normalize Empirical
    emp = df["Empirical"].astype(str).str.strip().str.lower()
    df["Empirical"] = emp.map({"yes": True, "no": False, "true": True, "false": False})
    if df["Empirical"].isna().any():
        bad = df.loc[df["Empirical"].isna(), "System"].tolist()
        raise ValueError(f"Empirical must be Yes/No (or True/False). Bad rows: {bad}")

    for c in ["Mass_eV","Width_eV","Chi"]:
        df[c] = pd.to_numeric(df[c], errors="raise")

    if (df["Mass_eV"] <= 0).any():
        raise ValueError("Mass_eV must be positive for all rows.")
    if (df["Width_eV"] <= 0).any():
        raise ValueError("Width_eV must be positive for all rows.")
    if (df["Chi"] <= 0).any():
        raise ValueError("Chi must be positive for all rows.")

    return df

def plot_chi_guides(ax, xmin, xmax, chis=(1.0, 0.1, 0.01, 10.0)):
    xs = np.linspace(xmin, xmax, 400)
    for chi in chis:
        # Gamma = 2*chi*omega  ->  log10(Gamma) = log10(omega) + log10(2*chi)
        ys = xs + math.log10(2.0 * chi)
        ax.plot(xs, ys, linewidth=1.0, linestyle="--")
    # Label chi=1 line: y = x + log10(2) = x + 0.301
    chi1_y = (xmax - 0.5) + math.log10(2.0)
    ax.text(xmax - 0.5, chi1_y, r"$\chi=1$", fontsize=11, ha="left", va="bottom")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--title", default="Cross-scale stability classification (data-driven rebuild)")
    ap.add_argument("--xmin", type=float, default=None)
    ap.add_argument("--xmax", type=float, default=None)
    ap.add_argument("--ymin", type=float, default=None)
    ap.add_argument("--ymax", type=float, default=None)
    ap.add_argument("--dpi", type=int, default=300)
    args = ap.parse_args()

    df = load_csv(args.csv)

    x = np.log10(df["Mass_eV"].to_numpy())
    y = np.log10(df["Width_eV"].to_numpy())

    xmin = float(np.min(x)) if args.xmin is None else args.xmin
    xmax = float(np.max(x)) if args.xmax is None else args.xmax
    ymin = float(np.min(y)) if args.ymin is None else args.ymin
    ymax = float(np.max(y)) if args.ymax is None else args.ymax

    # A little padding
    pad = 0.5
    xmin -= pad; xmax += pad; ymin -= pad; ymax += pad

    fig = plt.figure(figsize=(9.2, 6.2))
    ax = fig.add_subplot(111)

    # Guides
    plot_chi_guides(ax, xmin, xmax)

    # Plot points grouped by Category
    for cat, sub in df.groupby(df["Category"].astype(str)):
        marker, size = CAT_STYLE.get(cat, ("o", 55))
        xs = np.log10(sub["Mass_eV"].to_numpy())
        ys = np.log10(sub["Width_eV"].to_numpy())

        # Empirical: filled; Non-empirical: hollow
        emp_mask = sub["Empirical"].to_numpy().astype(bool)
        if np.any(emp_mask):
            ax.scatter(xs[emp_mask], ys[emp_mask], s=size, marker=marker)
        if np.any(~emp_mask):
            ax.scatter(xs[~emp_mask], ys[~emp_mask], s=size, marker=marker, facecolors="none")

        # Optional: label only non-empirical anchors to avoid clutter
        for _, row in sub.loc[~emp_mask].iterrows():
            ax.text(math.log10(row["Mass_eV"])+0.08, math.log10(row["Width_eV"])+0.08,
                    str(row["System"]), fontsize=8)

    ax.set_xlim(xmin, xmax)
    ax.set_ylim(ymin, ymax)
    ax.set_xlabel(r"$\log_{10}\,\omega$  (eV)")
    ax.set_ylabel(r"$\log_{10}\,\Gamma$  (eV)")
    ax.set_title(args.title)

    ax.grid(True, which="both", linestyle=":", linewidth=0.7)

    fig.tight_layout()
    fig.savefig(args.out, dpi=args.dpi)
    print(f"Saved: {args.out}")

if __name__ == "__main__":
    main()
