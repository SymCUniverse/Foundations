#!/usr/bin/env python3
"""chi_null_tests.py

Run referee-grade null tests for chi-compression.

Works with your canonical CSV schema:
System,Mass_eV,Width_eV,Chi,Category,Empirical,Notes

Outputs:
- chi_null_summary.csv
- chi_null_results.json

Also supports:
- short-lived subset tests
- censored (upper-bound) imputation
"""

from __future__ import annotations
import argparse, json, math, os
from typing import Dict, Tuple
import numpy as np
import pandas as pd

REQUIRED_COLS = ["System","Mass_eV","Width_eV","Chi","Category","Empirical","Notes"]

def safe_log10(a: np.ndarray) -> np.ndarray:
    a = np.asarray(a, dtype=float)
    if np.any(a <= 0):
        raise ValueError("log10 requires positive values.")
    return np.log10(a)

def linregress(x: np.ndarray, y: np.ndarray) -> Tuple[float,float]:
    x = np.asarray(x, dtype=float); y = np.asarray(y, dtype=float)
    X = np.vstack([np.ones_like(x), x]).T
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    return float(beta[0]), float(beta[1])

def residual_sd(x: np.ndarray, y: np.ndarray) -> float:
    a,b = linregress(x,y)
    r = y - (a + b*x)
    return float(np.std(r, ddof=1))

def spearman_rho(x: np.ndarray, y: np.ndarray) -> float:
    rx = pd.Series(x).rank(method="average").to_numpy()
    ry = pd.Series(y).rank(method="average").to_numpy()
    rxm, rym = rx-rx.mean(), ry-ry.mean()
    denom = np.sqrt(np.sum(rxm**2)*np.sum(rym**2))
    return float(np.sum(rxm*rym)/denom) if denom else float("nan")

def p_left(null: np.ndarray, obs: float) -> float:
    return float(np.mean(null <= obs))

def ensure_dir(p: str) -> None:
    os.makedirs(p, exist_ok=True)

def load_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    df["Empirical"] = df["Empirical"].astype(str).str.strip().str.lower().map({"yes": True, "no": False})
    if df["Empirical"].isna().any():
        bad = df.loc[df["Empirical"].isna(), "System"].tolist()
        raise ValueError(f"Empirical must be Yes/No. Bad rows: {bad}")
    for c in ["Mass_eV","Width_eV","Chi"]:
        df[c] = pd.to_numeric(df[c], errors="raise")
    if (df["Mass_eV"]<=0).any(): raise ValueError("Non-positive Mass_eV present.")
    if (df["Chi"]<=0).any(): raise ValueError("Non-positive Chi present.")
    return df

def make_subsets(df: pd.DataFrame, include_quarks_in_s2: bool) -> Dict[str,pd.DataFrame]:
    s1 = df[df["Empirical"]==True].copy()
    if include_quarks_in_s2:
        s2 = df[(df["Empirical"]==True) | (df["Category"].astype(str).str.lower()=="quark")].copy()
    else:
        s2 = s1.copy()
    s3 = df.copy()
    return {"S1": s1, "S2": s2, "S3": s3}

def observed_stats(df: pd.DataFrame) -> Dict[str,float]:
    x = safe_log10(df["Mass_eV"].to_numpy())
    y = safe_log10(df["Chi"].to_numpy())
    return {
        "n": int(len(df)),
        "T_range": float(y.max()-y.min()),
        "T_res": residual_sd(x,y),
        "spearman_rho": spearman_rho(x,y),
    }

def sim_N1_perm(x: np.ndarray, y: np.ndarray, n: int, rng: np.random.Generator) -> Dict[str,np.ndarray]:
    Tres = np.empty(n); rho = np.empty(n)
    for i in range(n):
        yp = rng.permutation(y)
        Tres[i] = residual_sd(x, yp)
        rho[i] = spearman_rho(x, yp)
    return {"T_res": Tres, "rho": rho}

def sim_N2_logunif(x: np.ndarray, ylo: float, yhi: float, n: int, rng: np.random.Generator) -> Dict[str,np.ndarray]:
    Tres = np.empty(n); Tr = np.empty(n); rho = np.empty(n)
    for i in range(n):
        ys = rng.uniform(ylo, yhi, size=len(x))
        Tr[i] = float(ys.max()-ys.min())
        Tres[i] = residual_sd(x, ys)
        rho[i] = spearman_rho(x, ys)
    return {"T_range": Tr, "T_res": Tres, "rho": rho}

def sim_N3_trend(x: np.ndarray, y: np.ndarray, n: int, rng: np.random.Generator) -> Dict[str,np.ndarray]:
    a,b = linregress(x,y)
    r = y - (a+b*x)
    sig = float(np.std(r, ddof=1))
    Tres = np.empty(n); Tr = np.empty(n); rho = np.empty(n)
    for i in range(n):
        ys = a + b*x + rng.normal(0.0, sig, size=len(x))
        Tr[i] = float(ys.max()-ys.min())
        Tres[i] = residual_sd(x, ys)
        rho[i] = spearman_rho(x, ys)
    return {"T_range": Tr, "T_res": Tres, "rho": rho}

def is_upper_bound(notes: str) -> bool:
    s = str(notes).lower()
    return "upper bound" in s or "upper-bound" in s or "upperbound" in s

def impute_upper_bounds(df: pd.DataFrame, rng: np.random.Generator, chi_floor: float = 1e-60) -> pd.DataFrame:
    df2 = df.copy()
    mask = df2["Notes"].apply(is_upper_bound).to_numpy()
    y = safe_log10(df2["Chi"].to_numpy())
    ylo = math.log10(chi_floor)
    for i, m in enumerate(mask):
        if m:
            y[i] = rng.uniform(ylo, y[i])  # log-uniform below bound
    df2["Chi"] = 10.0**y
    return df2

def run_subset(df: pd.DataFrame, n_mc: int, rng: np.random.Generator, ylo: float, yhi: float) -> Dict:
    obs = observed_stats(df)
    x = safe_log10(df["Mass_eV"].to_numpy())
    y = safe_log10(df["Chi"].to_numpy())

    n1 = sim_N1_perm(x,y,n_mc,rng)
    n2 = sim_N2_logunif(x,ylo,yhi,n_mc,rng)
    n3 = sim_N3_trend(x,y,n_mc,rng)

    return {
        "observed": obs,
        "pvals": {
            "N1_Tres": p_left(n1["T_res"], obs["T_res"]),
            "N1_abs_rho_ge": float(np.mean(np.abs(n1["rho"]) >= abs(obs["spearman_rho"]))),
            "N2_Trange": p_left(n2["T_range"], obs["T_range"]),
            "N2_Tres": p_left(n2["T_res"], obs["T_res"]),
            "N2_abs_rho_ge": float(np.mean(np.abs(n2["rho"]) >= abs(obs["spearman_rho"]))),
            "N3_Trange": p_left(n3["T_range"], obs["T_range"]),
            "N3_Tres": p_left(n3["T_res"], obs["T_res"]),
            "N3_abs_rho_ge": float(np.mean(np.abs(n3["rho"]) >= abs(obs["spearman_rho"]))),
        }
    }

def run_censored(df: pd.DataFrame, n_impute: int, n_mc: int, rng: np.random.Generator, ylo: float, yhi: float) -> Dict:
    p_samples = []
    for _ in range(n_impute):
        di = impute_upper_bounds(df, rng)
        r = run_subset(di, n_mc=n_mc, rng=rng, ylo=ylo, yhi=yhi)
        p_samples.append({**r["pvals"], "obs_Tres": r["observed"]["T_res"], "obs_Trange": r["observed"]["T_range"]})
    p_df = pd.DataFrame(p_samples)
    summ = p_df.describe(percentiles=[0.05,0.5,0.95]).to_dict()
    return {"n_impute": n_impute, "samples": p_samples, "summary": summ}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--n_mc", type=int, default=10000)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--include_quarks_in_s2", action="store_true")
    ap.add_argument("--y_low", type=float, default=-60.0)
    ap.add_argument("--y_high", type=float, default=1.5)
    ap.add_argument("--n_impute", type=int, default=200)
    args = ap.parse_args()

    ensure_dir(args.out)
    rng = np.random.default_rng(args.seed)

    df = load_csv(args.csv)
    subsets = make_subsets(df, include_quarks_in_s2=args.include_quarks_in_s2)

    results = {}
    for name, sdf in subsets.items():
        if len(sdf) < 6:
            results[name] = {"note": f"subset too small n={len(sdf)}"}
            continue
        res = run_subset(sdf, n_mc=args.n_mc, rng=rng, ylo=args.y_low, yhi=args.y_high)
        # censored analysis if any upper bounds
        ub_n = int(sdf["Notes"].apply(is_upper_bound).sum())
        res["upper_bounds_n"] = ub_n
        if ub_n > 0:
            res["censored"] = run_censored(sdf, n_impute=args.n_impute, n_mc=max(2000, args.n_mc//5), rng=rng, ylo=args.y_low, yhi=args.y_high)
        results[name] = res

    with open(os.path.join(args.out, "chi_null_results.json"), "w") as f:
        json.dump(results, f, indent=2)

    rows = []
    for sname, res in results.items():
        if "observed" not in res: 
            continue
        obs = res["observed"]; p = res["pvals"]
        rows.append({
            "subset": sname, "n": obs["n"],
            "T_range_obs": obs["T_range"], "T_res_obs": obs["T_res"], "spearman_obs": obs["spearman_rho"],
            **p
        })
    pd.DataFrame(rows).to_csv(os.path.join(args.out, "chi_null_summary.csv"), index=False)
    print("Wrote chi_null_results.json and chi_null_summary.csv to", args.out)

if __name__ == "__main__":
    main()
