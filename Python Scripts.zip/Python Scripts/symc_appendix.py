# Appendix A: Reproducible numerics for settling-time vs chi
# Requirements: numpy, scipy, matplotlib (optional)
import numpy as np
from scipy.integrate import solve_ivp

Omega = 1.0
Gamma_grid = np.linspace(0.05, 3.0, 296)
chi = Gamma_grid / (2.0 * abs(Omega))

def f(t, y, Gamma, Omega):
    x, v = y
    return [v, -Gamma * v - (Omega**2) * x]

def settling_time(Gamma, eps=1e-3, tmax=60.0, x0=1.0, v0=0.0):
    sol = solve_ivp(f, [0.0, tmax], [x0, v0],
                    args=(Gamma, Omega),
                    atol=1e-9, rtol=1e-9, max_step=0.01)
    x = sol.y[0]; t = sol.t
    for i in range(len(t)):
        if np.all(np.abs(x[i:]) <= eps):
            return t[i]
    return np.nan

Ts = np.array([settling_time(G) for G in Gamma_grid])
np.savetxt('symc_settling_times.csv', np.c_[chi, Ts],
           delimiter=',', header='chi,Ts', comments='')

if __name__ == "__main__":
    try:
        import matplotlib.pyplot as plt
        plt.plot(chi, Ts)
        plt.xlabel(r'$\chi$'); plt.ylabel('Settling time $T_s$'); plt.grid(True)
        plt.title('Settling Time vs. Chi')
        plt.savefig('fig_settling_vs_chi.png', dpi=200, bbox_inches='tight')
    except Exception as e:
        print("Plotting skipped or failed:", e)
